﻿namespace AngularApplication.Server.Models
{
    public class ContactModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}
