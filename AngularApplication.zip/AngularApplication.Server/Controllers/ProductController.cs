﻿using AngularApplication.Server.Entities;
using AngularApplication.Server.Interfaces;
using AngularApplication.Server.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AngularApplication.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        private readonly IContactRepository _ContactRepository;
        public ContactController(IContactRepository ContactRepository)
        {
            _ContactRepository = ContactRepository;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Contact>> Get(int id)
        {
            var result = await _ContactRepository.GetById(id);

            return result;
        }
        [HttpGet]
        public async Task<IEnumerable<Contact>> Get()
        {
            var result = await _ContactRepository.GetAll();
            return result;
        }

        [HttpPut]
        public async Task<bool> Put([FromBody] ContactModel model)
        {
            var result = await _ContactRepository.UpdateContact(model);
            return result > 0;
        }

        [HttpPost]
        public async Task<bool> Post([FromBody] ContactModel model)
        {
            var result = await _ContactRepository.AddContact(model);
            return result > 0;
        }

        [HttpDelete("{id}")]
        public async Task<bool> Delete(int id)
        {
            var result = await _ContactRepository.DeleteContact(id);
            return result > 0;
        }
    }
}
