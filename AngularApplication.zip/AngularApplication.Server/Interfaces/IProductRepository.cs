﻿using AngularApplication.Server.Entities;
using AngularApplication.Server.Models;

namespace AngularApplication.Server.Interfaces
{
    public interface IContactRepository : IGenericRepository<Contact>
    {
        Task<IEnumerable<Contact>> GetList();
        Task<Contact> GetContact(int Id);
        Task<int> AddContact(ContactModel Contactmodel);
        Task<int> UpdateContact(ContactModel Contactmodel);
        Task<int> DeleteContact(int Id);
    }
}
