﻿using AngularApplication.Server.Data;
using AngularApplication.Server.Entities;
using AngularApplication.Server.Interfaces;
using AngularApplication.Server.Models;

namespace AngularApplication.Server.Repositories
{
    public class ContactRepository : GenericRepository<Contact>, IContactRepository
    {
        public ContactRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<int> AddContact(ContactModel model)
        {
            Contact Contact = new Contact
            {
                Name = model.Name,
                Price = model.Price,
            };

            var result = await Add(Contact);
            return result;
        }

        public async Task<IEnumerable<Contact>> GetList()
        {
            return await GetAll();
        }

        public async Task<int> DeleteContact(int Id)
        {
            var Contactitem = await GetById(Id);

            var result = await Remove(Contactitem);
            return result;
        }

        public async Task<Contact> GetContact(int Id)
        {
            var Contactitem = await GetById(Id);
            return Contactitem;
        }

        public async Task<int> UpdateContact(ContactModel model)
        {
            var Contactitem = await GetById(model.Id);

            Contactitem.Name = model.Name;
            Contactitem.Price = model.Price;
            var result = await Update(Contactitem);
            return result;

        }

    }
}
